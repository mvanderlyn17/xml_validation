from xml.dom import minidom
from xml.etree import ElementTree
def main(stuff, morestuff):
    xmldoc = minidom.parse(xmlfilename)


    print 'hi'
    return 5
